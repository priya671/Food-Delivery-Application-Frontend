import { DummyPayment } from './dummy-payment';

describe('DummyPayment', () => {
  it('should create an instance', () => {
    expect(new DummyPayment()).toBeTruthy();
  });
});
